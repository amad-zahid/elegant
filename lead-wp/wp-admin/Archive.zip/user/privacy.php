<?php
/**
 * User Dashboard Privacy administration panel.
 *
 * @package WordPress
 * @subpackage Administration
 * @since 4.9.0
 */

/** Load WordPress Administration Bootstrap */
require_once __DIR__ . '/admin.php';

require ABSPATH . 'wp-admin/privacy.php';
