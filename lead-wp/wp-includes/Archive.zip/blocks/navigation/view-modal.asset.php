<?php return array('dependencies' => array(), 'version' => '6391fb107a84d15c14f4');
